//#ifndef MESSAGEDELETGE_H
//#define MESSAGEDELETGE_H

//#include <QObject>
//#include <QPainter>
//#include <QStyledItemDelegate>
//#include <QModelIndex>
//#include <QStyleOptionViewItem>
//class MessageDeletge : public QStyledItemDelegate
//{
//    Q_OBJECT
//    //重绘制以及处理发送的信息
//public:
//    explicit MessageDeletge(QObject *parent = nullptr);
//    void paint(QPainter *painter,const QStyleOptionViewItem &option,
//               const QModelIndex &index)const;
//    QSize sizeHint(const QStyleOptionViewItem &option,
//                   const QModelIndex &index)const;
//private:
//    void drawImage(QPainter *painter,const QStyleOptionViewItem &option
//                   ,const QVariantMap &data,bool isSelf)const;
//    void drawMessage(QPainter *painter,const QStyleOptionViewItem &option
//                     ,const QVariantMap &data,bool isSelf)const;
//    void drawFile(QPainter *painter,const QStyleOptionViewItem &option
//                  ,const QVariantMap &data,bool isSelf)const;

//signals:

//public slots:
//};

//#endif // MESSAGEDELETGE_H
