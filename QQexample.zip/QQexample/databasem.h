#ifndef DATABASEM_H
#define DATABASEM_H
#include <QSqlDatabase>
extern QSqlDatabase DB1;

#endif // DATABASEM_H
