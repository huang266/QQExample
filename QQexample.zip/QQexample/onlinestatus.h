#ifndef ONLINESTATUS_H
#define ONLINESTATUS_H
#include <QMap>
extern QMap<QString,bool>onLine;
void initOnlineStatus();
#endif // ONLINESTATUS_H
